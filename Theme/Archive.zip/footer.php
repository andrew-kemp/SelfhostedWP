<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> SelfhostedWP. All rights reserved.</p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
