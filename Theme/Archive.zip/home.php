<?php
get_header();
?>
<main>
    <section class="home-content">
        <h1>Welcome to SelfhostedWP!</h1>
        <p>This is your custom WordPress theme homepage.</p>
    </section>
</main>
<?php
get_footer();
